package project_api.project_api.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.*;

import project_api.project_api.model.Cliente;

@RestController
@RequestMapping("/project_api/clientes")
public class ClienteController {
    private List<Cliente> clientes = new ArrayList<>();

    public ClienteController() {
        clientes.add(new Cliente(1L, "João"));
        clientes.add(new Cliente(2L, "Maria"));
    }

    @GetMapping
    public List<Cliente> listar() {
        return clientes;
    }

    @GetMapping("/{id}")
    public Cliente buscarPorId(@PathVariable Long id) {
        return clientes.stream().filter(c -> c.getId().equals(id)).findFirst().orElse(null);
    }

    @PostMapping
    public Cliente criar(@RequestBody Cliente cliente) {
        clientes.add(cliente);
        return cliente;
    }
}
